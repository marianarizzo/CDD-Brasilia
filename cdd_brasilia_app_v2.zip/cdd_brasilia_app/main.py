from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = os.getenv("CDD_DB_PATH", str(DATA_DIR / "app.db"))
CDD_NAME = os.getenv("CDD_NAME", "CDD BRASÍLIA")

app = FastAPI(title="CDD Brasília | Etiquetas")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with closing(get_db()) as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo TEXT NOT NULL,
                origem TEXT NOT NULL,
                produto TEXT NOT NULL,
                recebimento TEXT NOT NULL,
                conferente TEXT NOT NULL,
                vencimento TEXT NOT NULL,
                rua TEXT NOT NULL,
                endereco TEXT NOT NULL,
                quantidade INTEGER NOT NULL,
                observacao TEXT,
                status TEXT NOT NULL DEFAULT 'PENDENTE',
                created_at TEXT NOT NULL,
                printed_at TEXT,
                printed_by TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
            CREATE INDEX IF NOT EXISTS idx_requests_rua_endereco ON requests(rua, endereco);
            """
        )
        conn.commit()


@app.on_event("startup")
def startup_event() -> None:
    init_db()


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, status: str = "PENDENTE") -> HTMLResponse:
    if status not in {"PENDENTE", "IMPRESSO", "TODOS"}:
        status = "PENDENTE"

    with closing(get_db()) as conn:
        params: list[Any] = []
        where_clause = ""
        if status != "TODOS":
            where_clause = "WHERE status = ?"
            params.append(status)

        groups = conn.execute(
            f"""
            SELECT
                rua,
                endereco,
                COUNT(*) AS total_solicitacoes,
                SUM(quantidade) AS total_folhas,
                MIN(created_at) AS primeira_solicitacao,
                MAX(created_at) AS ultima_solicitacao,
                SUM(CASE WHEN status = 'PENDENTE' THEN quantidade ELSE 0 END) AS folhas_pendentes,
                GROUP_CONCAT(id) AS ids
            FROM requests
            {where_clause}
            GROUP BY rua, endereco
            ORDER BY ultima_solicitacao DESC, rua ASC, endereco ASC
            """,
            params,
        ).fetchall()

        totals = conn.execute(
            """
            SELECT
                COUNT(*) AS total_registros,
                COALESCE(SUM(quantidade), 0) AS total_folhas,
                COALESCE(SUM(CASE WHEN status = 'PENDENTE' THEN quantidade ELSE 0 END), 0) AS pendentes,
                COALESCE(SUM(CASE WHEN status = 'IMPRESSO' THEN quantidade ELSE 0 END), 0) AS impressas
            FROM requests
            """
        ).fetchone()

        street_groups = conn.execute(
            f"""
            SELECT
                rua,
                COUNT(*) AS total_solicitacoes,
                COUNT(DISTINCT endereco) AS total_enderecos,
                COALESCE(SUM(quantidade), 0) AS total_folhas,
                COALESCE(SUM(CASE WHEN status = 'PENDENTE' THEN quantidade ELSE 0 END), 0) AS folhas_pendentes,
                GROUP_CONCAT(id) AS ids
            FROM requests
            {where_clause}
            GROUP BY rua
            ORDER BY rua ASC
            """,
            params,
        ).fetchall()

    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "groups": groups,
            "street_groups": street_groups,
            "status": status,
            "totals": totals,
            "cdd_name": CDD_NAME,
            "page_title": "Painel de etiquetas",
        },
    )


@app.get("/nova", response_class=HTMLResponse)
def new_request_form(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        "new_request.html",
        {
            "request": request,
            "cdd_name": CDD_NAME,
            "page_title": "Nova solicitação",
        },
    )


@app.post("/nova")
def create_request(
    codigo: str = Form(...),
    origem: str = Form(...),
    produto: str = Form(...),
    recebimento: str = Form(...),
    conferente: str = Form(...),
    vencimento: str = Form(...),
    rua: str = Form(...),
    endereco: str = Form(...),
    quantidade: int = Form(...),
    observacao: str = Form(""),
) -> RedirectResponse:
    if quantidade <= 0:
        raise HTTPException(status_code=400, detail="A quantidade deve ser maior que zero.")

    now = datetime.now().isoformat(timespec="seconds")
    with closing(get_db()) as conn:
        conn.execute(
            """
            INSERT INTO requests (
                codigo, origem, produto, recebimento, conferente, vencimento,
                rua, endereco, quantidade, observacao, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDENTE', ?)
            """,
            (
                codigo.strip(),
                origem.strip(),
                produto.strip(),
                recebimento.strip(),
                conferente.strip(),
                vencimento.strip(),
                rua.strip(),
                endereco.strip(),
                quantidade,
                observacao.strip(),
                now,
            ),
        )
        conn.commit()

    return RedirectResponse(url="/?status=PENDENTE", status_code=303)


@app.get("/rua", response_class=HTMLResponse)
def street_detail(request: Request, rua: str, status: str = "TODOS") -> HTMLResponse:
    if status not in {"PENDENTE", "IMPRESSO", "TODOS"}:
        status = "TODOS"

    with closing(get_db()) as conn:
        params: list[Any] = [rua]
        where_clause = "WHERE rua = ?"
        if status != "TODOS":
            where_clause += " AND status = ?"
            params.append(status)

        items = conn.execute(
            f"""
            SELECT *
            FROM requests
            {where_clause}
            ORDER BY endereco ASC, CASE status WHEN 'PENDENTE' THEN 0 ELSE 1 END, created_at DESC
            """,
            params,
        ).fetchall()

        if not items:
            raise HTTPException(status_code=404, detail="Rua não encontrada.")

        summary = conn.execute(
            f"""
            SELECT
                rua,
                COUNT(*) AS total_solicitacoes,
                COUNT(DISTINCT endereco) AS total_enderecos,
                COALESCE(SUM(quantidade), 0) AS total_folhas,
                COALESCE(SUM(CASE WHEN status = 'PENDENTE' THEN quantidade ELSE 0 END), 0) AS folhas_pendentes
            FROM requests
            {where_clause}
            GROUP BY rua
            """,
            params,
        ).fetchone()

    return templates.TemplateResponse(
        "street_detail.html",
        {
            "request": request,
            "items": items,
            "rua": rua,
            "status": status,
            "summary": summary,
            "cdd_name": CDD_NAME,
            "page_title": f"Rua | {rua}",
        },
    )


@app.get("/grupo", response_class=HTMLResponse)
def group_detail(request: Request, rua: str, endereco: str) -> HTMLResponse:
    with closing(get_db()) as conn:
        items = conn.execute(
            """
            SELECT *
            FROM requests
            WHERE rua = ? AND endereco = ?
            ORDER BY CASE status WHEN 'PENDENTE' THEN 0 ELSE 1 END, created_at DESC
            """,
            (rua, endereco),
        ).fetchall()

        if not items:
            raise HTTPException(status_code=404, detail="Grupo não encontrado.")

    return templates.TemplateResponse(
        "group_detail.html",
        {
            "request": request,
            "items": items,
            "rua": rua,
            "endereco": endereco,
            "cdd_name": CDD_NAME,
            "page_title": f"Grupo | {rua} - {endereco}",
        },
    )


@app.get("/imprimir", response_class=HTMLResponse)
def print_view(request: Request, ids: str) -> HTMLResponse:
    raw_ids = [item.strip() for item in ids.split(",") if item.strip()]
    if not raw_ids:
        raise HTTPException(status_code=400, detail="Nenhuma solicitação informada.")

    try:
        ids_int = [int(item) for item in raw_ids]
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="IDs inválidos.") from exc

    placeholders = ",".join("?" for _ in ids_int)
    with closing(get_db()) as conn:
        rows = conn.execute(
            f"SELECT * FROM requests WHERE id IN ({placeholders}) ORDER BY rua, endereco, created_at ASC",
            ids_int,
        ).fetchall()

    if not rows:
        raise HTTPException(status_code=404, detail="Nenhuma solicitação encontrada.")

    pages: list[dict[str, Any]] = []
    for row in rows:
        for copy_number in range(1, row["quantidade"] + 1):
            pages.append({"row": row, "copy_number": copy_number})

    return templates.TemplateResponse(
        "print.html",
        {
            "request": request,
            "pages": pages,
            "ids": ",".join(str(v) for v in ids_int),
            "cdd_name": CDD_NAME,
            "page_title": "Impressão de etiquetas",
        },
    )


@app.post("/marcar-impresso")
def mark_printed(ids: str = Form(...), printed_by: str = Form("")) -> RedirectResponse:
    raw_ids = [item.strip() for item in ids.split(",") if item.strip()]
    if not raw_ids:
        raise HTTPException(status_code=400, detail="Nenhuma solicitação informada.")

    try:
        ids_int = [int(item) for item in raw_ids]
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="IDs inválidos.") from exc

    placeholders = ",".join("?" for _ in ids_int)
    now = datetime.now().isoformat(timespec="seconds")
    with closing(get_db()) as conn:
        conn.execute(
            f"""
            UPDATE requests
            SET status = 'IMPRESSO', printed_at = ?, printed_by = ?
            WHERE id IN ({placeholders})
            """,
            [now, printed_by.strip() or "Operação"] + ids_int,
        )
        conn.commit()

    return RedirectResponse(url="/?status=IMPRESSO", status_code=303)


@app.post("/reabrir/{request_id}")
def reopen_request(request_id: int) -> RedirectResponse:
    with closing(get_db()) as conn:
        conn.execute(
            "UPDATE requests SET status = 'PENDENTE', printed_at = NULL, printed_by = NULL WHERE id = ?",
            (request_id,),
        )
        conn.commit()
    return RedirectResponse(url="/?status=PENDENTE", status_code=303)


@app.get("/api/health")
def healthcheck() -> dict[str, str]:
    return {"status": "ok"}


def br_datetime(value: str | None) -> str:
    if not value:
        return "-"
    try:
        dt = datetime.fromisoformat(value)
        return dt.strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return value


def urlencode(value: str) -> str:
    return quote(value)


templates.env.filters['br_datetime'] = br_datetime
templates.env.filters['urlencode'] = urlencode
